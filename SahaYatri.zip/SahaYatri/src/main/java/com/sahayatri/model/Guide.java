package com.sahayatri.model;

public class Guide extends User {
    private String specialization;
    private int experience;
    private double rating;

    public Guide(String username, String password, String fullName, String phoneNumber) {
        super(username, password, fullName, phoneNumber, UserRole.GUIDE);
        this.rating = 0.0;
    }

    public Guide(String username, String password, String fullName, String phoneNumber,
                 String specialization, int experience) {
        super(username, password, fullName, phoneNumber, UserRole.GUIDE);
        this.specialization = specialization;
        this.experience = experience;
        this.rating = 0.0;
    }

    public String getSpecialization() { return specialization; }
    public void setSpecialization(String specialization) { this.specialization = specialization; }

    public int getExperience() { return experience; }
    public void setExperience(int experience) { this.experience = experience; }

    public double getRating() { return rating; }
    public void setRating(double rating) { this.rating = rating; }
}