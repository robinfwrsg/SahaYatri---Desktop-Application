package com.sahayatri.model;

public class Destination {
    private String name;
    private String description;
    private String difficulty;
    private int duration;
    private double cost;
    private String region;

    public Destination(String name, String description, String difficulty, int duration, double cost, String region) {
        this.name = name;
        this.description = description;
        this.difficulty = difficulty;
        this.duration = duration;
        this.cost = cost;
        this.region = region;
    }

    // Getters and Setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getDifficulty() { return difficulty; }
    public void setDifficulty(String difficulty) { this.difficulty = difficulty; }

    public int getDuration() { return duration; }
    public void setDuration(int duration) { this.duration = duration; }

    public double getCost() { return cost; }
    public void setCost(double cost) { this.cost = cost; }

    public String getRegion() { return region; }
    public void setRegion(String region) { this.region = region; }

    @Override
    public String toString() {
        return name + " (" + difficulty + " - " + duration + " days)";
    }
}