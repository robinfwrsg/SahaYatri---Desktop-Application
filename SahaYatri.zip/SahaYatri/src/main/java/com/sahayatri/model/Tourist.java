package com.sahayatri.model;

public class Tourist extends User {
    private String email;
    private String address;

    public Tourist(String username, String password, String fullName, String phoneNumber) {
        super(username, password, fullName, phoneNumber, UserRole.TOURIST);
    }

    public Tourist(String username, String password, String fullName, String phoneNumber, String email, String address) {
        super(username, password, fullName, phoneNumber, UserRole.TOURIST);
        this.email = email;
        this.address = address;
    }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
}