package com.sahayatri.model;

public class Admin extends User {
    private String department;

    public Admin(String username, String password, String fullName, String phoneNumber) {
        super(username, password, fullName, phoneNumber, UserRole.ADMIN);
    }

    public Admin(String username, String password, String fullName, String phoneNumber, String department) {
        super(username, password, fullName, phoneNumber, UserRole.ADMIN);
        this.department = department;
    }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }
}