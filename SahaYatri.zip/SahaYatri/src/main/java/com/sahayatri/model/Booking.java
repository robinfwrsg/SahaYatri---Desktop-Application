package com.sahayatri.model;

import java.time.LocalDate;

public class Booking {
    private static int nextId = 1;
    private int bookingId;
    private String touristUsername;
    private String touristName;
    private String touristPhone;
    private String destinationName;
    private String guideName;
    private LocalDate trekDate;
    private BookingStatus status;
    private double cost;

    public enum BookingStatus {
        PENDING, CONFIRMED, CANCELLED, COMPLETED
    }

    public Booking(String touristUsername, String touristName, String touristPhone,
                   String destinationName, String guideName, LocalDate trekDate) {
        this.bookingId = nextId++;
        this.touristUsername = touristUsername;
        this.touristName = touristName;
        this.touristPhone = touristPhone;
        this.destinationName = destinationName;
        this.guideName = guideName;
        this.trekDate = trekDate;
        this.status = BookingStatus.CONFIRMED;
        this.cost = 0.0;
    }

    // Getters and Setters
    public int getBookingId() { return bookingId; }

    public String getTouristUsername() { return touristUsername; }
    public void setTouristUsername(String touristUsername) { this.touristUsername = touristUsername; }

    public String getTouristName() { return touristName; }
    public void setTouristName(String touristName) { this.touristName = touristName; }

    public String getTouristPhone() { return touristPhone; }
    public void setTouristPhone(String touristPhone) { this.touristPhone = touristPhone; }

    public String getDestinationName() { return destinationName; }
    public void setDestinationName(String destinationName) { this.destinationName = destinationName; }

    public String getGuideName() { return guideName; }
    public void setGuideName(String guideName) { this.guideName = guideName; }

    public LocalDate getTrekDate() { return trekDate; }
    public void setTrekDate(LocalDate trekDate) { this.trekDate = trekDate; }

    public BookingStatus getStatus() { return status; }
    public void setStatus(BookingStatus status) { this.status = status; }

    public double getCost() { return cost; }
    public void setCost(double cost) { this.cost = cost; }
}