package com.sahayatri.utils;

import com.sahayatri.model.Booking;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class CSVExporter {

    public static boolean exportBookingsToCSV(List<Booking> bookings, String filename) {
        try (FileWriter writer = new FileWriter(filename)) {
            // Write header
            writer.append("Booking ID,Tourist Name,Tourist Phone,Destination,Guide,Trek Date,Status\n");

            // Write data
            for (Booking booking : bookings) {
                writer.append(String.valueOf(booking.getBookingId())).append(",");
                writer.append(booking.getTouristName()).append(",");
                writer.append(booking.getTouristPhone()).append(",");
                writer.append(booking.getDestinationName()).append(",");
                writer.append(booking.getGuideName()).append(",");
                writer.append(booking.getTrekDate().toString()).append(",");
                writer.append(booking.getStatus().toString()).append("\n");
            }

            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
}