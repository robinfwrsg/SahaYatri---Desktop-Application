package com.sahayatri.utils;

import com.sahayatri.model.*;
import java.time.LocalDate;
import java.util.*;

public class DataManager {
    private static DataManager instance;
    private Map<String, User> users;
    private List<Booking> bookings;
    private List<Destination> destinations;
    private User currentUser;

    private DataManager() {
        users = new HashMap<>();
        bookings = new ArrayList<>();
        destinations = new ArrayList<>();
    }

    public static DataManager getInstance() {
        if (instance == null) {
            instance = new DataManager();
        }
        return instance;
    }

    public void initializeData() {
        // Initialize users
        users.put("admin", new Admin("admin", "admin123", "Admin User", "9841000000"));
        users.put("tourist", new Tourist("tourist", "tourist123", "John Doe", "9841111111"));
        users.put("guide", new Guide("guide", "guide123", "Ram Bahadur", "9841222222", "Mountain Trekking", 5));

        // Add more sample users
        users.put("guide2", new Guide("guide2", "guide123", "Shyam Gurung", "9841333333", "Cultural Tours", 3));
        users.put("guide3", new Guide("guide3", "guide123", "Krishna Tamang", "9841444444", "Adventure Sports", 7));

        // Initialize destinations
        destinations.add(new Destination("Everest Base Camp", "Trek to the base camp of the world's highest mountain", "Hard", 14, 1200.0, "Khumbu"));
        destinations.add(new Destination("Annapurna Circuit", "Complete circuit around the Annapurna massif", "Moderate", 12, 800.0, "Annapurna"));
        destinations.add(new Destination("Langtang Valley", "Beautiful valley trek with mountain views", "Easy", 7, 500.0, "Langtang"));
        destinations.add(new Destination("Manaslu Circuit", "Less crowded alternative to Annapurna", "Hard", 16, 1000.0, "Manaslu"));
        destinations.add(new Destination("Gokyo Lakes", "Beautiful glacial lakes in Everest region", "Moderate", 10, 900.0, "Khumbu"));

        // Initialize sample bookings
        bookings.add(new Booking("tourist", "John Doe", "9841111111", "Everest Base Camp", "Ram Bahadur", LocalDate.now().plusDays(30)));
        bookings.add(new Booking("tourist", "John Doe", "9841111111", "Annapurna Circuit", "Shyam Gurung", LocalDate.now().plusDays(60)));
    }

    // User management
    public User authenticateUser(String username, String password) {
        User user = users.get(username);
        if (user != null && user.getPassword().equals(password)) {
            currentUser = user;
            return user;
        }
        return null;
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(User user) {
        this.currentUser = user;
    }

    // Booking management
    public void addBooking(Booking booking) {
        bookings.add(booking);
    }

    public List<Booking> getAllBookings() {
        return new ArrayList<>(bookings);
    }

    public List<Booking> getBookingsForTourist(String touristUsername) {
        return bookings.stream()
                .filter(booking -> booking.getTouristUsername().equals(touristUsername))
                .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }

    public List<Booking> getBookingsForGuide(String guideName) {
        return bookings.stream()
                .filter(booking -> booking.getGuideName().equals(guideName))
                .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }

    // Destination management
    public List<Destination> getAllDestinations() {
        return new ArrayList<>(destinations);
    }

    public void addDestination(Destination destination) {
        destinations.add(destination);
    }

    public void removeDestination(String destinationName) {
        destinations.removeIf(dest -> dest.getName().equals(destinationName));
    }

    // Guide management
    public List<Guide> getAllGuides() {
        return users.values().stream()
                .filter(user -> user instanceof Guide)
                .map(user -> (Guide) user)
                .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }

    // Statistics
    public Map<String, Integer> getDestinationPopularity() {
        Map<String, Integer> popularity = new HashMap<>();
        for (Booking booking : bookings) {
            popularity.merge(booking.getDestinationName(), 1, Integer::sum);
        }
        return popularity;
    }
}