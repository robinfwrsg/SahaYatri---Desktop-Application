package com.sahayatri.controller;

import com.sahayatri.SahaYatriApp;
import com.sahayatri.model.Booking;
import com.sahayatri.model.Destination;
import com.sahayatri.utils.CSVExporter;
import com.sahayatri.utils.ChartGenerator;
import com.sahayatri.utils.DataManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.FileChooser;

import java.io.File;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public class AdminDashboardController {

    @FXML private Label welcomeLabel;
    @FXML private TableView<Booking> bookingsTable;
    @FXML private TableColumn<Booking, Integer> bookingIdColumn;
    @FXML private TableColumn<Booking, String> touristNameColumn;
    @FXML private TableColumn<Booking, String> touristPhoneColumn;
    @FXML private TableColumn<Booking, String> destinationColumn;
    @FXML private TableColumn<Booking, String> guideColumn;
    @FXML private TableColumn<Booking, LocalDate> dateColumn;
    @FXML private TableColumn<Booking, String> statusColumn;

    @FXML private ListView<Destination> destinationsListView;
    @FXML private TextField destinationNameField;
    @FXML private TextArea destinationDescriptionField;
    @FXML private ComboBox<String> difficultyComboBox;
    @FXML private TextField durationField;
    @FXML private TextField costField;
    @FXML private TextField regionField;

    @FXML private BarChart<String, Number> popularityChart;

    private DataManager dataManager = DataManager.getInstance();

    @FXML
    private void initialize() {
        welcomeLabel.setText("Welcome, " + dataManager.getCurrentUser().getFullName());

        setupBookingsTable();
        setupDestinationsListView();
        setupDifficultyComboBox();
        loadBookings();
        loadDestinations();
        updateChart();
    }

    private void setupBookingsTable() {
        bookingIdColumn.setCellValueFactory(new PropertyValueFactory<>("bookingId"));
        touristNameColumn.setCellValueFactory(new PropertyValueFactory<>("touristName"));
        touristPhoneColumn.setCellValueFactory(new PropertyValueFactory<>("touristPhone"));
        destinationColumn.setCellValueFactory(new PropertyValueFactory<>("destinationName"));
        guideColumn.setCellValueFactory(new PropertyValueFactory<>("guideName"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("trekDate"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
    }

    private void setupDestinationsListView() {
        destinationsListView.setCellFactory(listView -> new ListCell<Destination>() {
            @Override
            protected void updateItem(Destination destination, boolean empty) {
                super.updateItem(destination, empty);
                if (empty || destination == null) {
                    setText(null);
                } else {
                    setText(destination.getName() + " - " + destination.getDifficulty() +
                            " (" + destination.getDuration() + " days, $" + destination.getCost() + ")");
                }
            }
        });
    }

    private void setupDifficultyComboBox() {
        difficultyComboBox.setItems(FXCollections.observableArrayList("Easy", "Moderate", "Hard"));
    }

    private void loadBookings() {
        List<Booking> bookings = dataManager.getAllBookings();
        ObservableList<Booking> observableBookings = FXCollections.observableArrayList(bookings);
        bookingsTable.setItems(observableBookings);
    }

    private void loadDestinations() {
        List<Destination> destinations = dataManager.getAllDestinations();
        ObservableList<Destination> observableDestinations = FXCollections.observableArrayList(destinations);
        destinationsListView.setItems(observableDestinations);
    }

    private void updateChart() {
        Map<String, Integer> popularityData = dataManager.getDestinationPopularity();
        BarChart<String, Number> newChart = ChartGenerator.createDestinationPopularityChart(popularityData);

        // Copy chart data to existing chart
        popularityChart.getData().clear();
        popularityChart.getData().addAll(newChart.getData());
        popularityChart.setTitle("Destination Popularity");
    }

    @FXML
    private void handleAddDestination() {
        String name = destinationNameField.getText().trim();
        String description = destinationDescriptionField.getText().trim();
        String difficulty = difficultyComboBox.getValue();
        String durationText = durationField.getText().trim();
        String costText = costField.getText().trim();
        String region = regionField.getText().trim();

        if (name.isEmpty() || description.isEmpty() || difficulty == null ||
                durationText.isEmpty() || costText.isEmpty() || region.isEmpty()) {
            showAlert("Error", "Please fill in all fields.", Alert.AlertType.ERROR);
            return;
        }

        try {
            int duration = Integer.parseInt(durationText);
            double cost = Double.parseDouble(costText);

            Destination newDestination = new Destination(name, description, difficulty, duration, cost, region);
            dataManager.addDestination(newDestination);

            loadDestinations();
            updateChart();
            clearDestinationFields();

            showAlert("Success", "Destination added successfully!", Alert.AlertType.INFORMATION);
        } catch (NumberFormatException e) {
            showAlert("Error", "Duration must be a valid number and cost must be a valid decimal.", Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleRemoveDestination() {
        Destination selected = destinationsListView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Error", "Please select a destination to remove.", Alert.AlertType.ERROR);
            return;
        }

        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
        confirmation.setTitle("Confirm Deletion");
        confirmation.setHeaderText("Remove Destination");
        confirmation.setContentText("Are you sure you want to remove '" + selected.getName() + "'?");

        if (confirmation.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
            dataManager.removeDestination(selected.getName());
            loadDestinations();
            updateChart();
            showAlert("Success", "Destination removed successfully!", Alert.AlertType.INFORMATION);
        }
    }

    @FXML
    private void handleExportCSV() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Bookings CSV");
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("CSV files (*.csv)", "*.csv")
        );
        fileChooser.setInitialFileName("bookings_export.csv");

        File file = fileChooser.showSaveDialog(SahaYatriApp.getPrimaryStage());
        if (file != null) {
            List<Booking> bookings = dataManager.getAllBookings();
            if (CSVExporter.exportBookingsToCSV(bookings, file.getAbsolutePath())) {
                showAlert("Success", "Bookings exported successfully to " + file.getName(), Alert.AlertType.INFORMATION);
            } else {
                showAlert("Error", "Failed to export bookings. Please try again.", Alert.AlertType.ERROR);
            }
        }
    }

    @FXML
    private void handleRefresh() {
        loadBookings();
        loadDestinations();
        updateChart();
    }

    @FXML
    private void handleLogout() {
        dataManager.setCurrentUser(null);
        SahaYatriApp.switchScene("/fxml/login.fxml", "SahaYatri - Login");
    }

    private void clearDestinationFields() {
        destinationNameField.clear();
        destinationDescriptionField.clear();
        difficultyComboBox.setValue(null);
        durationField.clear();
        costField.clear();
        regionField.clear();
    }

    private void showAlert(String title, String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}