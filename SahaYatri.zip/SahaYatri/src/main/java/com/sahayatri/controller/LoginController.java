package com.sahayatri.controller;

import com.sahayatri.SahaYatriApp;
import com.sahayatri.model.User;
import com.sahayatri.utils.DataManager;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class LoginController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label errorLabel;
    @FXML private Button loginButton;

    @FXML
    private void initialize() {
        errorLabel.setVisible(false);

        // Add enter key functionality
        usernameField.setOnAction(e -> handleLogin());
        passwordField.setOnAction(e -> handleLogin());
    }

    @FXML
    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            showError("Please enter both username and password.");
            return;
        }

        User user = DataManager.getInstance().authenticateUser(username, password);

        if (user != null) {
            switch (user.getRole()) {
                case ADMIN:
                    SahaYatriApp.switchScene("/fxml/admin-dashboard.fxml", "SahaYatri - Admin Dashboard");
                    break;
                case TOURIST:
                    SahaYatriApp.switchScene("/fxml/tourist-dashboard.fxml", "SahaYatri - Tourist Dashboard");
                    break;
                case GUIDE:
                    SahaYatriApp.switchScene("/fxml/guide-dashboard.fxml", "SahaYatri - Guide Dashboard");
                    break;
            }
        } else {
            showError("Invalid username or password. Please try again.");
        }
    }

    private void showError(String message) {
        errorLabel.setText(message);
        errorLabel.setVisible(true);

        // Clear error after 3 seconds
        new Thread(() -> {
            try {
                Thread.sleep(3000);
                javafx.application.Platform.runLater(() -> errorLabel.setVisible(false));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }).start();
    }

    @FXML
    private void clearFields() {
        usernameField.clear();
        passwordField.clear();
        errorLabel.setVisible(false);
    }
}