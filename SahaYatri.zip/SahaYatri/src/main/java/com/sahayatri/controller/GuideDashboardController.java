package com.sahayatri.controller;

import com.sahayatri.SahaYatriApp;
import com.sahayatri.model.Booking;
import com.sahayatri.model.Guide;
import com.sahayatri.utils.DataManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.time.LocalDate;
import java.util.List;

public class GuideDashboardController {

    @FXML private Label welcomeLabel;
    @FXML private Label guideInfoLabel;

    // Assigned tourists table
    @FXML private TableView<Booking> assignedTouristsTable;
    @FXML private TableColumn<Booking, Integer> bookingIdColumn;
    @FXML private TableColumn<Booking, String> touristNameColumn;
    @FXML private TableColumn<Booking, String> touristPhoneColumn;
    @FXML private TableColumn<Booking, String> destinationColumn;
    @FXML private TableColumn<Booking, LocalDate> trekDateColumn;
    @FXML private TableColumn<Booking, Booking.BookingStatus> statusColumn;

    @FXML private Label totalAssignmentsLabel;
    @FXML private Label upcomingTreksLabel;

    private DataManager dataManager = DataManager.getInstance();
    private Guide currentGuide;

    @FXML
    private void initialize() {
        currentGuide = (Guide) dataManager.getCurrentUser();
        welcomeLabel.setText("Welcome, " + currentGuide.getFullName());

        setupGuideInfo();
        setupAssignedTouristsTable();
        loadAssignedTourists();
        updateStatistics();
    }

    private void setupGuideInfo() {
        String infoText = String.format("Specialization: %s | Experience: %d years | Rating: %.1f/5.0",
                currentGuide.getSpecialization() != null ? currentGuide.getSpecialization() : "General Trekking",
                currentGuide.getExperience(),
                currentGuide.getRating());
        guideInfoLabel.setText(infoText);
    }

    private void setupAssignedTouristsTable() {
        bookingIdColumn.setCellValueFactory(new PropertyValueFactory<>("bookingId"));
        touristNameColumn.setCellValueFactory(new PropertyValueFactory<>("touristName"));
        touristPhoneColumn.setCellValueFactory(new PropertyValueFactory<>("touristPhone"));
        destinationColumn.setCellValueFactory(new PropertyValueFactory<>("destinationName"));
        trekDateColumn.setCellValueFactory(new PropertyValueFactory<>("trekDate"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));

        // Custom cell factory for highlighting upcoming treks
        trekDateColumn.setCellFactory(column -> new TableCell<Booking, LocalDate>() {
            @Override
            protected void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                if (empty || date == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText(date.toString());

                    // Highlight upcoming treks (within next 7 days)
                    if (date.isAfter(LocalDate.now()) && date.isBefore(LocalDate.now().plusDays(8))) {
                        setStyle("-fx-background-color: #fff3cd; -fx-text-fill: #856404;");
                    } else if (date.isBefore(LocalDate.now())) {
                        setStyle("-fx-background-color: #f8d7da; -fx-text-fill: #721c24;");
                    } else {
                        setStyle("");
                    }
                }
            }
        });

        // Custom cell factory for status column
        statusColumn.setCellFactory(column -> new TableCell<Booking, Booking.BookingStatus>() {
            @Override
            protected void updateItem(Booking.BookingStatus status, boolean empty) {
                super.updateItem(status, empty);
                if (empty || status == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText(status.toString());
                    switch (status) {
                        case CONFIRMED:
                            setStyle("-fx-background-color: #d4edda; -fx-text-fill: #155724;");
                            break;
                        case PENDING:
                            setStyle("-fx-background-color: #fff3cd; -fx-text-fill: #856404;");
                            break;
                        case CANCELLED:
                            setStyle("-fx-background-color: #f8d7da; -fx-text-fill: #721c24;");
                            break;
                        case COMPLETED:
                            setStyle("-fx-background-color: #d1ecf1; -fx-text-fill: #0c5460;");
                            break;
                        default:
                            setStyle("");
                    }
                }
            }
        });
    }

    private void loadAssignedTourists() {
        List<Booking> assignedBookings = dataManager.getBookingsForGuide(currentGuide.getFullName());
        ObservableList<Booking> observableBookings = FXCollections.observableArrayList(assignedBookings);
        assignedTouristsTable.setItems(observableBookings);
    }

    private void updateStatistics() {
        List<Booking> allAssignments = dataManager.getBookingsForGuide(currentGuide.getFullName());
        totalAssignmentsLabel.setText("Total Assignments: " + allAssignments.size());

        long upcomingCount = allAssignments.stream()
                .filter(booking -> booking.getTrekDate().isAfter(LocalDate.now()))
                .count();
        upcomingTreksLabel.setText("Upcoming Treks: " + upcomingCount);
    }

    @FXML
    private void handleViewTouristDetails() {
        Booking selectedBooking = assignedTouristsTable.getSelectionModel().getSelectedItem();
        if (selectedBooking == null) {
            showAlert("Information", "Please select a booking to view details.", Alert.AlertType.INFORMATION);
            return;
        }

        String details = String.format(
                "Booking Details:\n\n" +
                        "Booking ID: %d\n" +
                        "Tourist Name: %s\n" +
                        "Tourist Phone: %s\n" +
                        "Destination: %s\n" +
                        "Trek Date: %s\n" +
                        "Status: %s\n\n" +
                        "Days until trek: %d",
                selectedBooking.getBookingId(),
                selectedBooking.getTouristName(),
                selectedBooking.getTouristPhone(),
                selectedBooking.getDestinationName(),
                selectedBooking.getTrekDate().toString(),
                selectedBooking.getStatus().toString(),
                java.time.temporal.ChronoUnit.DAYS.between(LocalDate.now(), selectedBooking.getTrekDate())
        );

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Tourist Details");
        alert.setHeaderText("Booking Information");
        alert.setContentText(details);
        alert.showAndWait();
    }

    @FXML
    private void handleMarkCompleted() {
        Booking selectedBooking = assignedTouristsTable.getSelectionModel().getSelectedItem();
        if (selectedBooking == null) {
            showAlert("Information", "Please select a booking to mark as completed.", Alert.AlertType.INFORMATION);
            return;
        }

        if (selectedBooking.getTrekDate().isAfter(LocalDate.now())) {
            showAlert("Error", "Cannot mark future treks as completed.", Alert.AlertType.ERROR);
            return;
        }

        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
        confirmation.setTitle("Confirm Completion");
        confirmation.setHeaderText("Mark Trek as Completed");
        confirmation.setContentText("Are you sure you want to mark this trek as completed?");

        if (confirmation.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
            selectedBooking.setStatus(Booking.BookingStatus.COMPLETED);
            loadAssignedTourists();
            updateStatistics();
            showAlert("Success", "Trek marked as completed successfully!", Alert.AlertType.INFORMATION);
        }
    }

    @FXML
    private void handleFilterUpcoming() {
        List<Booking> allBookings = dataManager.getBookingsForGuide(currentGuide.getFullName());
        List<Booking> upcomingBookings = allBookings.stream()
                .filter(booking -> booking.getTrekDate().isAfter(LocalDate.now()))
                .collect(java.util.stream.Collectors.toList());

        ObservableList<Booking> observableBookings = FXCollections.observableArrayList(upcomingBookings);
        assignedTouristsTable.setItems(observableBookings);
    }

    @FXML
    private void handleShowAll() {
        loadAssignedTourists();
    }

    @FXML
    private void handleRefresh() {
        loadAssignedTourists();
        updateStatistics();
    }

    @FXML
    private void handleLogout() {
        dataManager.setCurrentUser(null);
        SahaYatriApp.switchScene("/fxml/login.fxml", "SahaYatri - Login");
    }

    private void showAlert(String title, String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
