package com.sahayatri.controller;

import com.sahayatri.SahaYatriApp;
import com.sahayatri.model.Booking;
import com.sahayatri.model.Destination;
import com.sahayatri.model.Guide;
import com.sahayatri.model.Tourist;
import com.sahayatri.utils.DataManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.time.LocalDate;
import java.util.List;

public class TouristDashboardController {

    @FXML private Label welcomeLabel;

    // Booking form elements
    @FXML private TextField touristNameField;
    @FXML private TextField touristPhoneField;
    @FXML private ComboBox<Destination> destinationComboBox;
    @FXML private ComboBox<Guide> guideComboBox;
    @FXML private DatePicker trekDatePicker;
    @FXML private Button bookButton;

    // Booking history table
    @FXML private TableView<Booking> bookingHistoryTable;
    @FXML private TableColumn<Booking, Integer> bookingIdColumn;
    @FXML private TableColumn<Booking, String> destinationColumn;
    @FXML private TableColumn<Booking, String> guideColumn;
    @FXML private TableColumn<Booking, LocalDate> dateColumn;
    @FXML private TableColumn<Booking, String> statusColumn;

    private DataManager dataManager = DataManager.getInstance();
    private Tourist currentTourist;

    @FXML
    private void initialize() {
        currentTourist = (Tourist) dataManager.getCurrentUser();
        welcomeLabel.setText("Welcome, " + currentTourist.getFullName());

        setupBookingForm();
        setupBookingHistoryTable();
        loadBookingHistory();
    }

    private void setupBookingForm() {
        // Pre-fill tourist info
        touristNameField.setText(currentTourist.getFullName());
        touristPhoneField.setText(currentTourist.getPhoneNumber());

        // Load destinations
        List<Destination> destinations = dataManager.getAllDestinations();
        ObservableList<Destination> observableDestinations = FXCollections.observableArrayList(destinations);
        destinationComboBox.setItems(observableDestinations);

        // Custom cell factory for destinations
        destinationComboBox.setCellFactory(listView -> new ListCell<Destination>() {
            @Override
            protected void updateItem(Destination destination, boolean empty) {
                super.updateItem(destination, empty);
                if (empty || destination == null) {
                    setText(null);
                } else {
                    setText(destination.getName() + " - " + destination.getDifficulty() +
                            " (" + destination.getDuration() + " days)");
                }
            }
        });

        destinationComboBox.setButtonCell(new ListCell<Destination>() {
            @Override
            protected void updateItem(Destination destination, boolean empty) {
                super.updateItem(destination, empty);
                if (empty || destination == null) {
                    setText(null);
                } else {
                    setText(destination.getName());
                }
            }
        });

        // Load guides
        List<Guide> guides = dataManager.getAllGuides();
        ObservableList<Guide> observableGuides = FXCollections.observableArrayList(guides);
        guideComboBox.setItems(observableGuides);

        // Custom cell factory for guides
        guideComboBox.setCellFactory(listView -> new ListCell<Guide>() {
            @Override
            protected void updateItem(Guide guide, boolean empty) {
                super.updateItem(guide, empty);
                if (empty || guide == null) {
                    setText(null);
                } else {
                    setText(guide.getFullName() + " - " + guide.getSpecialization() +
                            " (" + guide.getExperience() + " years exp.)");
                }
            }
        });

        guideComboBox.setButtonCell(new ListCell<Guide>() {
            @Override
            protected void updateItem(Guide guide, boolean empty) {
                super.updateItem(guide, empty);
                if (empty || guide == null) {
                    setText(null);
                } else {
                    setText(guide.getFullName());
                }
            }
        });

        // Set minimum date to today
        trekDatePicker.setValue(LocalDate.now().plusDays(1));
        trekDatePicker.setDayCellFactory(picker -> new DateCell() {
            @Override
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                setDisable(empty || date.isBefore(LocalDate.now()));
            }
        });
    }

    private void setupBookingHistoryTable() {
        bookingIdColumn.setCellValueFactory(new PropertyValueFactory<>("bookingId"));
        destinationColumn.setCellValueFactory(new PropertyValueFactory<>("destinationName"));
        guideColumn.setCellValueFactory(new PropertyValueFactory<>("guideName"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("trekDate"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
    }

    private void loadBookingHistory() {
        List<Booking> bookings = dataManager.getBookingsForTourist(currentTourist.getUsername());
        ObservableList<Booking> observableBookings = FXCollections.observableArrayList(bookings);
        bookingHistoryTable.setItems(observableBookings);
    }

    @FXML
    private void handleCreateBooking() {
        if (!validateBookingForm()) {
            return;
        }

        String touristName = touristNameField.getText().trim();
        String touristPhone = touristPhoneField.getText().trim();
        Destination selectedDestination = destinationComboBox.getValue();
        Guide selectedGuide = guideComboBox.getValue();
        LocalDate trekDate = trekDatePicker.getValue();

        Booking newBooking = new Booking(
                currentTourist.getUsername(),
                touristName,
                touristPhone,
                selectedDestination.getName(),
                selectedGuide.getFullName(),
                trekDate
        );

        dataManager.addBooking(newBooking);

        showAlert("Success", "Booking created successfully!\nBooking ID: " + newBooking.getBookingId(),
                Alert.AlertType.INFORMATION);

        clearBookingForm();
        loadBookingHistory();
    }

    private boolean validateBookingForm() {
        if (touristNameField.getText().trim().isEmpty()) {
            showAlert("Error", "Please enter your name.", Alert.AlertType.ERROR);
            return false;
        }

        if (touristPhoneField.getText().trim().isEmpty()) {
            showAlert("Error", "Please enter your phone number.", Alert.AlertType.ERROR);
            return false;
        }

        if (destinationComboBox.getValue() == null) {
            showAlert("Error", "Please select a destination.", Alert.AlertType.ERROR);
            return false;
        }

        if (guideComboBox.getValue() == null) {
            showAlert("Error", "Please select a guide.", Alert.AlertType.ERROR);
            return false;
        }

        if (trekDatePicker.getValue() == null) {
            showAlert("Error", "Please select a trek date.", Alert.AlertType.ERROR);
            return false;
        }

        if (trekDatePicker.getValue().isBefore(LocalDate.now())) {
            showAlert("Error", "Trek date cannot be in the past.", Alert.AlertType.ERROR);
            return false;
        }

        return true;
    }

    private void clearBookingForm() {
        destinationComboBox.setValue(null);
        guideComboBox.setValue(null);
        trekDatePicker.setValue(LocalDate.now().plusDays(1));
    }

    @FXML
    private void handleRefresh() {
        loadBookingHistory();

        // Refresh combo boxes
        List<Destination> destinations = dataManager.getAllDestinations();
        destinationComboBox.setItems(FXCollections.observableArrayList(destinations));

        List<Guide> guides = dataManager.getAllGuides();
        guideComboBox.setItems(FXCollections.observableArrayList(guides));
    }

    @FXML
    private void handleLogout() {
        dataManager.setCurrentUser(null);
        SahaYatriApp.switchScene("/fxml/login.fxml", "SahaYatri - Login");
    }

    private void showAlert(String title, String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}