module sahayatri {
    // JavaFX Core Modules
    requires javafx.controls;
    requires javafx.fxml;

    // Java Desktop Module for file operations (CSV export)
    requires java.desktop;

    // Required for FXML Controller injection and reflection
    requires java.base;

    // Exports for the main application package
    exports com.sahayatri;

    // Exports for controllers (needed for FXML loading)
    exports com.sahayatri.controller;

    // Exports for model classes (needed for TableView property binding)
    exports com.sahayatri.model;

    // Exports for utility classes
    exports com.sahayatri.utils;

    // Opens packages for FXML reflection access
    opens com.sahayatri to javafx.fxml;
    opens com.sahayatri.controller to javafx.fxml;
    opens com.sahayatri.model to javafx.base, javafx.fxml;
    opens com.sahayatri.utils to javafx.fxml;
}